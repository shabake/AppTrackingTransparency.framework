//
//  AppTrackingTransparency.h
//  AppTrackingTransparency
//
//  Copyright © 2020 Apple Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AppTrackingTransparency/ATTrackingManager.h>

FOUNDATION_EXPORT double AppTrackingTransparencyVersionNumber;
FOUNDATION_EXPORT const unsigned char AppTrackingTransparencyVersionString[];
